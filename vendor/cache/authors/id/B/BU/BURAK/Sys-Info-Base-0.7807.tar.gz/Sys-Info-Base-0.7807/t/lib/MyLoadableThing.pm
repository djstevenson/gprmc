package MyLoadableThing;

use strict;
use warnings;

sub fancy_sub {
    print "42\n";
}

1;

__END__

