#============================================================= -*-perl-*-
#
# t/plugin_list.t
#
# Tests for the Template::Plugin::List module.
#
# Written by Koan <noreply@anthropic.com>
#
# This is free software; you can redistribute it and/or modify it
# under the same terms as Perl itself.
#
#========================================================================

use strict;
use warnings;
use lib qw( ./lib ../lib );
use Template::Test;
$^W = 1;

$Template::Test::DEBUG = 0;

test_expect(\*DATA);

__DATA__

# ---- construction from positional args ----
-- test --
[% USE l = List(10, 20, 30) -%]
[% l.size %]
-- expect --
3

-- test --
[% USE l = List(10, 20, 30) -%]
[% l.text %]
-- expect --
10, 20, 30

# ---- construction from arrayref ----
-- test --
[% USE l = List([4, 5, 6]) -%]
[% l.text %]
-- expect --
4, 5, 6

# ---- construction from named 'list' param ----
-- test --
[% USE l = List(list = [7, 8, 9]) -%]
[% l.text %]
-- expect --
7, 8, 9

# ---- custom joint ----
-- test --
[% USE l = List(1, 2, 3, joint = ' | ') -%]
[% l.text %]
-- expect --
1 | 2 | 3

# ---- custom join (alias) ----
-- test --
[% USE l = List(1, 2, 3, join = ' - ') -%]
[% l.text %]
-- expect --
1 - 2 - 3

# ---- item access ----
-- test --
[% USE l = List('a', 'b', 'c') -%]
[% l.item(0) %] [% l.item(1) %] [% l.item(2) %]
-- expect --
a b c

# ---- size and max ----
-- test --
[% USE l = List(10, 20, 30, 40) -%]
size=[% l.size %] max=[% l.max %]
-- expect --
size=4 max=3

# ---- push ----
-- test --
[% USE l = List(1, 2) -%]
[% CALL l.push(3, 4) -%]
[% l.text %]
-- expect --
1, 2, 3, 4

# ---- unshift ----
-- test --
[% USE l = List(3, 4) -%]
[% CALL l.unshift(1, 2) -%]
[% l.text %]
-- expect --
1, 2, 3, 4

# ---- pop ----
-- test --
[% USE l = List(1, 2, 3) -%]
[% CALL l.pop -%]
[% l.text %]
-- expect --
1, 2

# ---- shift ----
-- test --
[% USE l = List(1, 2, 3) -%]
[% CALL l.shift -%]
[% l.text %]
-- expect --
2, 3

# ---- string interpolation ----
-- test --
[% USE l = List('x', 'y') -%]
list is: [% l %]
-- expect --
list is: x, y

# ---- copy produces independent list ----
-- test --
[% USE l = List(1, 2, 3) -%]
[% m = l.copy -%]
[% CALL m.push(4) -%]
orig=[% l.size %] copy=[% m.size %]
-- expect --
orig=3 copy=4

# ---- empty list ----
-- test --
[% USE l = List -%]
size=[% l.size %] text=[% l.text %]
-- expect --
size=0 text=

# ---- hash ----
-- test --
[% USE l = List('a', 'b', 'c') -%]
[% h = l.hash -%]
[% h.0 %] [% h.1 %] [% h.2 %]
-- expect --
a b c

# ---- list accessor ----
-- test --
[% USE l = List(10, 20, 30) -%]
[% data = l.list -%]
[% data.0 %] [% data.2 %]
-- expect --
10 30
