test
% die;
123
