/*
 * foo.js asset
 */
